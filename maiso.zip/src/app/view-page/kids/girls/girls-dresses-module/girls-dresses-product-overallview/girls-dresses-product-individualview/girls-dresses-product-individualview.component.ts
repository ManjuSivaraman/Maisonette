import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-girls-dresses-product-individualview',
  templateUrl: './girls-dresses-product-individualview.component.html',
  styleUrls: ['./girls-dresses-product-individualview.component.css']
})
export class GirlsDressesProductIndividualviewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
