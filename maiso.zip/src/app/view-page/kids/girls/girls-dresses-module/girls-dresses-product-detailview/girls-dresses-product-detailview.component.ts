import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-girls-dresses-product-detailview',
  templateUrl: './girls-dresses-product-detailview.component.html',
  styleUrls: ['./girls-dresses-product-detailview.component.css']
})
export class GirlsDressesProductDetailviewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
